/*    */ package com.baidu.ueditor.define;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class ActionMap
/*    */ {
/* 26 */   public static final Map<String, Integer> mapping = new HashMap() {  } ;
/*    */   public static final int CONFIG = 0;
/*    */   public static final int UPLOAD_IMAGE = 1;
/*    */   public static final int UPLOAD_SCRAWL = 2;
/*    */   public static final int UPLOAD_VIDEO = 3;
/*    */   public static final int UPLOAD_FILE = 4;
/*    */   public static final int CATCH_IMAGE = 5;
/*    */   public static final int LIST_FILE = 6;
/*    */   public static final int LIST_IMAGE = 7;
/*    */ 
/* 39 */   public static int getType(String key) { return ((Integer)mapping.get(key)).intValue(); }
/*    */ 
/*    */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.define.ActionMap
 * JD-Core Version:    0.6.2
 */