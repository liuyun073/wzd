/*    */ package com.baidu.ueditor.define;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class FileType
/*    */ {
/*    */   public static final String JPG = "JPG";
/* 10 */   private static final Map<String, String> types = new HashMap() { } ;
/*    */ 
/*    */   public static String getSuffix(String key)
/*    */   {
/* 17 */     return (String)types.get(key);
/*    */   }
/*    */ 
/*    */   public static String getSuffixByFilename(String filename)
/*    */   {
/* 27 */     return filename.substring(filename.lastIndexOf(".")).toLowerCase();
/*    */   }
/*    */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.define.FileType
 * JD-Core Version:    0.6.2
 */