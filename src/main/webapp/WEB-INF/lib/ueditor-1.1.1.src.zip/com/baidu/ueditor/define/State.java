package com.baidu.ueditor.define;

public abstract interface State
{
  public abstract boolean isSuccess();

  public abstract void putInfo(String paramString1, String paramString2);

  public abstract void putInfo(String paramString, long paramLong);

  public abstract String toJSONString();
}

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.define.State
 * JD-Core Version:    0.6.2
 */