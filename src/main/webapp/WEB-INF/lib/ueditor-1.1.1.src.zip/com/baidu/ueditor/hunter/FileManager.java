/*     */ package com.baidu.ueditor.hunter;
/*     */ 
/*     */ import com.baidu.ueditor.PathFormat;
/*     */ import com.baidu.ueditor.define.BaseState;
/*     */ import com.baidu.ueditor.define.MultiState;
/*     */ import com.baidu.ueditor.define.State;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ 
/*     */ public class FileManager
/*     */ {
/*  18 */   private String dir = null;
/*  19 */   private String rootPath = null;
/*  20 */   private String[] allowFiles = null;
/*  21 */   private int count = 0;
/*     */ 
/*     */   public FileManager(Map<String, Object> conf)
/*     */   {
/*  25 */     this.rootPath = ((String)conf.get("rootPath"));
/*  26 */     this.dir = (this.rootPath + (String)conf.get("dir"));
/*  27 */     this.allowFiles = getAllowFiles(conf.get("allowFiles"));
/*  28 */     this.count = ((Integer)conf.get("count")).intValue();
/*     */   }
/*     */ 
/*     */   public State listFile(int index)
/*     */   {
/*  34 */     File dir = new File(this.dir);
/*  35 */     State state = null;
/*     */ 
/*  37 */     if (!dir.exists()) {
/*  38 */       return new BaseState(false, 302);
/*     */     }
/*     */ 
/*  41 */     if (!dir.isDirectory()) {
/*  42 */       return new BaseState(false, 301);
/*     */     }
/*     */ 
/*  45 */     Collection list = FileUtils.listFiles(dir, this.allowFiles, true);
/*     */ 
/*  47 */     if ((index < 0) || (index > list.size())) {
/*  48 */       state = new MultiState(true);
/*     */     } else {
/*  50 */       Object[] fileList = Arrays.copyOfRange(list.toArray(), index, index + this.count);
/*  51 */       state = getState(fileList);
/*     */     }
/*     */ 
/*  54 */     state.putInfo("start", index);
/*  55 */     state.putInfo("total", list.size());
/*     */ 
/*  57 */     return state;
/*     */   }
/*     */ 
/*     */   private State getState(Object[] files)
/*     */   {
/*  63 */     MultiState state = new MultiState(true);
/*  64 */     BaseState fileState = null;
/*     */ 
/*  66 */     File file = null;
/*     */ 
/*  68 */     for (Object obj : files) {
/*  69 */       if (obj == null) {
/*     */         break;
/*     */       }
/*  72 */       file = (File)obj;
/*  73 */       fileState = new BaseState(true);
/*  74 */       fileState.putInfo("url", PathFormat.format(getPath(file)));
/*  75 */       state.addState(fileState);
/*     */     }
/*     */ 
/*  78 */     return state;
/*     */   }
/*     */ 
/*     */   private String getPath(File file)
/*     */   {
/*  84 */     String path = file.getAbsolutePath();
/*     */ 
/*  86 */     return path.replace(this.rootPath, "/");
/*     */   }
/*     */ 
/*     */   private String[] getAllowFiles(Object fileExt)
/*     */   {
/*  92 */     String[] exts = null;
/*  93 */     String ext = null;
/*     */ 
/*  95 */     if (fileExt == null) {
/*  96 */       return new String[0];
/*     */     }
/*     */ 
/*  99 */     exts = (String[])fileExt;
/*     */ 
/* 101 */     int i = 0; for (int len = exts.length; i < len; i++)
/*     */     {
/* 103 */       ext = exts[i];
/* 104 */       exts[i] = ext.replace(".", "");
/*     */     }
/*     */ 
/* 108 */     return exts;
/*     */   }
/*     */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.hunter.FileManager
 * JD-Core Version:    0.6.2
 */