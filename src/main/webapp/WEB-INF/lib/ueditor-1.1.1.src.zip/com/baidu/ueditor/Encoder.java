/*    */ package com.baidu.ueditor;
/*    */ 
/*    */ public class Encoder
/*    */ {
/*    */   public static String toUnicode(String input)
/*    */   {
/*  7 */     StringBuilder builder = new StringBuilder();
/*  8 */     char[] chars = input.toCharArray();
/*    */ 
/* 10 */     for (char ch : chars)
/*    */     {
/* 12 */       if (ch < 'Ā')
/* 13 */         builder.append(ch);
/*    */       else {
/* 15 */         builder.append("\\u" + Integer.toHexString(ch & 0xFFFF));
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 20 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.Encoder
 * JD-Core Version:    0.6.2
 */