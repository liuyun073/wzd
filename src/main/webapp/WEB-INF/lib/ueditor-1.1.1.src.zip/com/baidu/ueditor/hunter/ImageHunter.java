/*     */ package com.baidu.ueditor.hunter;
/*     */ 
/*     */ import com.baidu.ueditor.PathFormat;
/*     */ import com.baidu.ueditor.define.BaseState;
/*     */ import com.baidu.ueditor.define.MIMEType;
/*     */ import com.baidu.ueditor.define.MultiState;
/*     */ import com.baidu.ueditor.define.State;
/*     */ import com.baidu.ueditor.upload.StorageManager;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ImageHunter
/*     */ {
/*  24 */   private String filename = null;
/*  25 */   private String savePath = null;
/*  26 */   private String rootPath = null;
/*  27 */   private List<String> allowTypes = null;
/*  28 */   private long maxSize = -1L;
/*     */ 
/*  30 */   private List<String> filters = null;
/*     */ 
/*     */   public ImageHunter(Map<String, Object> conf)
/*     */   {
/*  34 */     this.filename = ((String)conf.get("filename"));
/*  35 */     this.savePath = ((String)conf.get("savePath"));
/*  36 */     this.rootPath = ((String)conf.get("rootPath"));
/*  37 */     this.maxSize = ((Long)conf.get("maxSize")).longValue();
/*  38 */     this.allowTypes = Arrays.asList((String[])conf.get("allowFiles"));
/*  39 */     this.filters = Arrays.asList((String[])conf.get("filter"));
/*     */   }
/*     */ 
/*     */   public State capture(String[] list)
/*     */   {
/*  45 */     MultiState state = new MultiState(true);
/*     */ 
/*  47 */     for (String source : list) {
/*  48 */       state.addState(captureRemoteData(source));
/*     */     }
/*     */ 
/*  51 */     return state;
/*     */   }
/*     */ 
/*     */   public State captureRemoteData(String urlStr)
/*     */   {
/*  57 */     HttpURLConnection connection = null;
/*  58 */     URL url = null;
/*  59 */     String suffix = null;
/*     */     try
/*     */     {
/*  62 */       url = new URL(urlStr);
/*     */ 
/*  64 */       if (!validHost(url.getHost())) {
/*  65 */         return new BaseState(false, 201);
/*     */       }
/*     */ 
/*  68 */       connection = (HttpURLConnection)url.openConnection();
/*     */ 
/*  70 */       connection.setInstanceFollowRedirects(true);
/*  71 */       connection.setUseCaches(true);
/*     */ 
/*  73 */       if (!validContentState(connection.getResponseCode())) {
/*  74 */         return new BaseState(false, 202);
/*     */       }
/*     */ 
/*  77 */       suffix = MIMEType.getSuffix(connection.getContentType());
/*     */ 
/*  79 */       if (!validFileType(suffix)) {
/*  80 */         return new BaseState(false, 8);
/*     */       }
/*     */ 
/*  83 */       if (!validFileSize(connection.getContentLength())) {
/*  84 */         return new BaseState(false, 1);
/*     */       }
/*     */ 
/*  87 */       String savePath = getPath(this.savePath, this.filename, suffix);
/*  88 */       String physicalPath = this.rootPath + savePath;
/*     */ 
/*  90 */       State state = StorageManager.saveFileByInputStream(connection.getInputStream(), physicalPath);
/*     */ 
/*  92 */       if (state.isSuccess()) {
/*  93 */         state.putInfo("url", PathFormat.format(savePath));
/*  94 */         state.putInfo("source", urlStr);
/*     */       }
/*     */ 
/*  97 */       return state;
/*     */     } catch (Exception e) {
/*     */     }
/* 100 */     return new BaseState(false, 203);
/*     */   }
/*     */ 
/*     */   private String getPath(String savePath, String filename, String suffix)
/*     */   {
/* 107 */     return PathFormat.parse(savePath + suffix, filename);
/*     */   }
/*     */ 
/*     */   private boolean validHost(String hostname)
/*     */   {
/* 113 */     return !this.filters.contains(hostname);
/*     */   }
/*     */ 
/*     */   private boolean validContentState(int code)
/*     */   {
/* 119 */     return 200 == code;
/*     */   }
/*     */ 
/*     */   private boolean validFileType(String type)
/*     */   {
/* 125 */     return this.allowTypes.contains(type);
/*     */   }
/*     */ 
/*     */   private boolean validFileSize(int size)
/*     */   {
/* 130 */     return size < this.maxSize;
/*     */   }
/*     */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.hunter.ImageHunter
 * JD-Core Version:    0.6.2
 */