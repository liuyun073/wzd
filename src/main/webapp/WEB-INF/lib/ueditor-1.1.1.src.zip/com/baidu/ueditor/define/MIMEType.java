/*    */ package com.baidu.ueditor.define;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MIMEType
/*    */ {
/*  8 */   public static final Map<String, String> types = new HashMap() { } ;
/*    */ 
/*    */   public static String getSuffix(String mime)
/*    */   {
/* 17 */     return (String)types.get(mime);
/*    */   }
/*    */ }

/* Location:           C:\Users\liyazhou\Downloads\a1b3ea95-60be-3e7c-a2b1-af921e4c4111.jar
 * Qualified Name:     com.baidu.ueditor.define.MIMEType
 * JD-Core Version:    0.6.2
 */